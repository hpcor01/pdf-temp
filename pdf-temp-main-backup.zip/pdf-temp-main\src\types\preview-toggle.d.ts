export interface PreviewToggleProps {
  isProcessing: boolean;
}
