interface BtnCreateColumnProps {
  onClick: (title?: string) => void;
  showPreviewPanel: boolean | null;
}

export type { BtnCreateColumnProps };
