export interface LoadingOverlayProps {
  message: string;
}
