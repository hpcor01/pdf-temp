import type { Column as ColumnType } from "@/types/kanban";

export interface ColumnProps {
  column: ColumnType;
  index: number;
}
