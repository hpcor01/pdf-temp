// Define the version response type
export interface VersionResponse {
  version: string;
}
