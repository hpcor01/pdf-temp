export interface HeaderProps {
  toggleAllColumnsSave?: (shouldSave: boolean) => void;
  onToggleAllChange?: (checked: boolean) => void;
}
